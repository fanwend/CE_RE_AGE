# -*- coding:utf-8 -*-

from Melodie import Scenario


class _ALIAS_Scenario(Scenario):
    def setup(self):
        self.period_num = 200
        pass
